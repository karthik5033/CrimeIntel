module.exports=[683468,(a,b,c)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_page_actions_1d5z7o4.js.map