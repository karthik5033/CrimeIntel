module.exports=[660467,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_firs_%5Bid%5D_page_actions_15uua0q.js.map