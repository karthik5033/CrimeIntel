module.exports=[544793,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_events_route_actions_0r48jk4.js.map