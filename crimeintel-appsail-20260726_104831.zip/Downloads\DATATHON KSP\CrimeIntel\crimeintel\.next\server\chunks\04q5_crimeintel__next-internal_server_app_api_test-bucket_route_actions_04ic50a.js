module.exports=[635427,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_test-bucket_route_actions_04ic50a.js.map