module.exports=[570547,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_search_page_actions_1l67ch5.js.map