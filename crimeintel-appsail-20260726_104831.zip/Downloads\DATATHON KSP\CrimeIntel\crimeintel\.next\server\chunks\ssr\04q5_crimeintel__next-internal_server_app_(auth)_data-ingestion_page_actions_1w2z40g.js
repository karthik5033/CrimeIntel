module.exports=[736626,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_data-ingestion_page_actions_1w2z40g.js.map