module.exports=[2279,(a,b,c)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app__not-found_page_actions_1y9_m1h.js.map