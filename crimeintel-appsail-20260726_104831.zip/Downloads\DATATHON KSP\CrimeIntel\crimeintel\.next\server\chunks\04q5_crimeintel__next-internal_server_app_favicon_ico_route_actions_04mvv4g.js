module.exports=[976658,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_favicon_ico_route_actions_04mvv4g.js.map