globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/lT06SWLlHyU2upbKoyoeA/_buildManifest.js",
    "static/lT06SWLlHyU2upbKoyoeA/_ssgManifest.js",
    "static/lT06SWLlHyU2upbKoyoeA/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3r7upmfi5qmr_.js",
    "static/chunks/3ic0i0vxcl5xk.js",
    "static/chunks/1yhq_95dz9aw4.js",
    "static/chunks/3un8_bk5vc114.js",
    "static/chunks/223dysacc1i39.js",
    "static/chunks/turbopack-3w5tuoj5sq-qf.js"
  ]
};
