module.exports=[907171,(e,o,d)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_api_ocr_route_actions_1om4gtq.js.map