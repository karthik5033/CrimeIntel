:HL["/_next/static/chunks/2hddxvzirlrjy.css","style"]
:HL["/_next/static/chunks/0rzx14p0iapca.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"lT06SWLlHyU2upbKoyoeA"}
