module.exports=[121114,(e,o,d)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_api_seed_route_actions_01ktr_6.js.map