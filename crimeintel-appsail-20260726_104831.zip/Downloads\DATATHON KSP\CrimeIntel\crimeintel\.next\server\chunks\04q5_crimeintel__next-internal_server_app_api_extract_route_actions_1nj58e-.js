module.exports=[91440,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_extract_route_actions_1nj58e-.js.map