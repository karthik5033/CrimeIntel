module.exports=[664567,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_embeddings_route_actions_1pyp9e-.js.map