module.exports=[276899,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_alerts_page_actions_0k_a69b.js.map