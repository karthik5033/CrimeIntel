module.exports=[500652,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_audit_page_actions_0kf-c2b.js.map