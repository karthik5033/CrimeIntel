1:"$Sreact.fragment"
2:I[875068,["/_next/static/chunks/13cje8svtz2yv.js","/_next/static/chunks/0ud6-w7yaujfg.js"],"ViewportBoundary"]
3:I[875068,["/_next/static/chunks/13cje8svtz2yv.js","/_next/static/chunks/0ud6-w7yaujfg.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[587145,["/_next/static/chunks/13cje8svtz2yv.js","/_next/static/chunks/0ud6-w7yaujfg.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lT06SWLlHyU2upbKoyoeA"}
