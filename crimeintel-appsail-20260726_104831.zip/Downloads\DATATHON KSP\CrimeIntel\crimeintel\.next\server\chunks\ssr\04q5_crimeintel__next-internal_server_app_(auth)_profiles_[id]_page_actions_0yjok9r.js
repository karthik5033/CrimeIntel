module.exports=[650224,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_profiles_%5Bid%5D_page_actions_0yjok9r.js.map