module.exports=[476916,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_dashboard_page_actions_0xfnbyd.js.map