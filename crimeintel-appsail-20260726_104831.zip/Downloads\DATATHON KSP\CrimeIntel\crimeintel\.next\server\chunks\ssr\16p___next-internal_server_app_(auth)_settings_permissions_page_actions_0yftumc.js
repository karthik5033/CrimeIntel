module.exports=[433121,(a,b,c)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_%28auth%29_settings_permissions_page_actions_0yftumc.js.map