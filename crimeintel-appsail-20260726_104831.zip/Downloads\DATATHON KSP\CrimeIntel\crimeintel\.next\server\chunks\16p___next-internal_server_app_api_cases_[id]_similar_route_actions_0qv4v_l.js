module.exports=[884743,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_cases_%5Bid%5D_similar_route_actions_0qv4v_l.js.map