module.exports=[799276,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_analytics_districts_route_actions_1a5z5rl.js.map