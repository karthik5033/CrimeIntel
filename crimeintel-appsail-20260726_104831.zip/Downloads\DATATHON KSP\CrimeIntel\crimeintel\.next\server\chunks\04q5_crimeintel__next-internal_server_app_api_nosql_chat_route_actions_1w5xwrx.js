module.exports=[383845,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_nosql_chat_route_actions_1w5xwrx.js.map