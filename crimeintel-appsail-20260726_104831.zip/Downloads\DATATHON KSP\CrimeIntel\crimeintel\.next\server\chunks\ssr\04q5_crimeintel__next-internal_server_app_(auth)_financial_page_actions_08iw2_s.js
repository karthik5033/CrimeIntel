module.exports=[336039,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_financial_page_actions_08iw2_s.js.map