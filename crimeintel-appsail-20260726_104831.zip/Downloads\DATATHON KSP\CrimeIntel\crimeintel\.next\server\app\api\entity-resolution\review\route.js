var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/entity-resolution/review/route.js")
R.c("server/chunks/[root-of-the-server]__0hw4lea._.js")
R.c("server/chunks/[root-of-the-server]__107vlgj._.js")
R.c("server/chunks/1u5-_next_0foo7x5._.js")
R.c("server/chunks/16p___next-internal_server_app_api_entity-resolution_review_route_actions_0jxnj89.js")
R.m(100202)
module.exports=R.m(100202).exports
