module.exports=[875420,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_analytics_comparative_route_actions_0poudih.js.map