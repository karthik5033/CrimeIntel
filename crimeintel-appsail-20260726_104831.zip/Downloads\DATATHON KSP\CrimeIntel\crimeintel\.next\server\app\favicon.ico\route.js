var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/1u5-_next_dist_esm_build_templates_app-route_0-tjgsx.js")
R.c("server/chunks/1u5-_next_0foo7x5._.js")
R.c("server/chunks/[root-of-the-server]__107vlgj._.js")
R.c("server/chunks/04q5_crimeintel__next-internal_server_app_favicon_ico_route_actions_04mvv4g.js")
R.m(228677)
module.exports=R.m(228677).exports
