module.exports=[168466,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_predictions_hotspot_route_actions_0r4n5kb.js.map