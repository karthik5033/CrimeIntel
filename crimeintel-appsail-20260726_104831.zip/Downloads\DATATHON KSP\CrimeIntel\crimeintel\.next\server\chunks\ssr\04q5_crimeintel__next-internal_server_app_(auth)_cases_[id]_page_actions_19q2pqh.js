module.exports=[606838,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_cases_%5Bid%5D_page_actions_19q2pqh.js.map