module.exports=[428476,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_predictions_offender_route_actions_1jr7oq1.js.map