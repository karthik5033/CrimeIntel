module.exports=[205093,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_audit_logs_route_actions_0mzt3_s.js.map