module.exports=[780189,(e,o,d)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_api_audit_route_actions_1kp98j5.js.map