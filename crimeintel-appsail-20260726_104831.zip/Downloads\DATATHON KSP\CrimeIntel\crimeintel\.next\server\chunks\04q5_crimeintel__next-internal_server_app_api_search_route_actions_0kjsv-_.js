module.exports=[591739,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_search_route_actions_0kjsv-_.js.map