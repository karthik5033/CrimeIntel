module.exports=[771865,(e,o,d)=>{}];

//# sourceMappingURL=16p___next-internal_server_app_api_predictions_anomaly_route_actions_1cadl2b.js.map