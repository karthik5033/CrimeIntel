module.exports=[985371,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_settings_page_actions_0sdd-_x.js.map