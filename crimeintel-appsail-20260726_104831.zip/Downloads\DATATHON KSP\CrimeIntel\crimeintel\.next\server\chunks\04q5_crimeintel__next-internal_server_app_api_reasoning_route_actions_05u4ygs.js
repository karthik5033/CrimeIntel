module.exports=[520373,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_reasoning_route_actions_05u4ygs.js.map