module.exports=[475129,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_upload_route_actions_1tq1mc_.js.map