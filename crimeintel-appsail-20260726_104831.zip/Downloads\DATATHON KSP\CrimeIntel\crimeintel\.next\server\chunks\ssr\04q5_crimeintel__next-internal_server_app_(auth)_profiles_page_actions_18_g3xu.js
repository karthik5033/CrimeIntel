module.exports=[905240,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_%28auth%29_profiles_page_actions_18_g3xu.js.map