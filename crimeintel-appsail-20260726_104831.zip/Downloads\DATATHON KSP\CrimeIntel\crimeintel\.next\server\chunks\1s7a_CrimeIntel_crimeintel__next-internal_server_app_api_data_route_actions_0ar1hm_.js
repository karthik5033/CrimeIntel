module.exports=[948585,(e,o,d)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_api_data_route_actions_0ar1hm_.js.map