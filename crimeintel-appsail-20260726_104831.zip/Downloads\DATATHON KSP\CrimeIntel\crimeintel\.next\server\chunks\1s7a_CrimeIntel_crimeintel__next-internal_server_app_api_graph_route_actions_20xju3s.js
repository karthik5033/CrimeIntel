module.exports=[332621,(e,o,d)=>{}];

//# sourceMappingURL=1s7a_CrimeIntel_crimeintel__next-internal_server_app_api_graph_route_actions_20xju3s.js.map