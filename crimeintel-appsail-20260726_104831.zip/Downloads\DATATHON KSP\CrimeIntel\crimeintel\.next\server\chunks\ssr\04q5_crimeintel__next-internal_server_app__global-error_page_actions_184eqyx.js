module.exports=[42115,(a,b,c)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app__global-error_page_actions_184eqyx.js.map