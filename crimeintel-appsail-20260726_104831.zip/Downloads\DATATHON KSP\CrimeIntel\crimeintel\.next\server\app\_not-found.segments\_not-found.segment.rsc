1:"$Sreact.fragment"
2:I[56905,["/_next/static/chunks/3rgbdii--cpa4.js","/_next/static/chunks/0ud6-w7yaujfg.js","/_next/static/chunks/0gfqgq9vd3x7n.js"],"default"]
3:I[721221,["/_next/static/chunks/3rgbdii--cpa4.js","/_next/static/chunks/0ud6-w7yaujfg.js","/_next/static/chunks/0gfqgq9vd3x7n.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"lT06SWLlHyU2upbKoyoeA"}
