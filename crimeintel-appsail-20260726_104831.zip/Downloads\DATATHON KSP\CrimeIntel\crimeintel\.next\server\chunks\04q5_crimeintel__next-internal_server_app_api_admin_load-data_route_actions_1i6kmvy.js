module.exports=[407831,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_admin_load-data_route_actions_1i6kmvy.js.map