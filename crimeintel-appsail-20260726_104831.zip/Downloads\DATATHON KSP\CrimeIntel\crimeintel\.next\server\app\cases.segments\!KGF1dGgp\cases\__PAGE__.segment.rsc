1:"$Sreact.fragment"
2:I[183785,["/_next/static/chunks/3rgbdii--cpa4.js","/_next/static/chunks/0ud6-w7yaujfg.js","/_next/static/chunks/0gfqgq9vd3x7n.js","/_next/static/chunks/28ht1squl01fi.js","/_next/static/chunks/3egq-b0dzprv-.js","/_next/static/chunks/2rln8dow47-af.js","/_next/static/chunks/1nch5z8ubaymz.js","/_next/static/chunks/17nb4te1xfk2j.js","/_next/static/chunks/2ey2b2h1rj1yf.js","/_next/static/chunks/051pg81vqrx8y.js"],"ClientCasesList"]
3:I[875068,["/_next/static/chunks/3rgbdii--cpa4.js","/_next/static/chunks/0ud6-w7yaujfg.js","/_next/static/chunks/0gfqgq9vd3x7n.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{"initialCases":[]}],[["$","script","script-0",{"src":"/_next/static/chunks/2ey2b2h1rj1yf.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/051pg81vqrx8y.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lT06SWLlHyU2upbKoyoeA"}
5:null
