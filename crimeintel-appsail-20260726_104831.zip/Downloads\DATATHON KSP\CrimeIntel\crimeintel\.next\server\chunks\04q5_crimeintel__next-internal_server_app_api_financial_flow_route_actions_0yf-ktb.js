module.exports=[589571,(e,o,d)=>{}];

//# sourceMappingURL=04q5_crimeintel__next-internal_server_app_api_financial_flow_route_actions_0yf-ktb.js.map